const DBconnect = require('../config/DBconnect');

const addLoading = (req, res) => {
    const { total_value, repID, addedItems, vehicleID, userID, loading_status, areaID } = req.body;
    const date = new Date().toISOString().slice(0, 19).replace("T", " ");
    
    // Start a transaction
    DBconnect.getConnection((err, connection) => {
        if (err) {
            console.error('Error getting database connection:', err);
            res.status(500).send('Internal Server Error');
            return;
        }

        connection.beginTransaction((err) => {
            if (err) {
                console.error('Error starting database transaction:', err);
                connection.release();
                res.status(500).send('Internal Server Error');
                return;
            }

            // Insert into loading table
            const insertLoadingQuery = 'INSERT INTO loading (total_value, repID, vehicleID, date, userID, loading_status, areaID) VALUES (?, ?, ?, ?, ?, ?, ?)';
            connection.query(insertLoadingQuery, [total_value, repID, vehicleID, date, userID, loading_status, areaID], (err, loadingResult) => {
                if (err) {
                    console.error('Error inserting item into loading table:', err);
                    connection.rollback(() => {
                        connection.release();
                        res.status(500).send('Internal Server Error');
                    });
                    return;
                }

                const loadingID = loadingResult.insertId;

                // Prepare values for bulk insertion into loading_products table
                const productSaleValues = addedItems.map((item) => [
                    loadingID,
                    item.productID,
                    item.quantity,
                ]);

                // Insert into loading_products table
                const insertLoadingProductsQuery = 'INSERT INTO loading_products (loadingID, productID, quantity) VALUES ?';
                connection.query(insertLoadingProductsQuery, [productSaleValues], (err, productsResult) => {
                    if (err) {
                        console.error('Error inserting items into loading_products table:', err);
                        connection.rollback(() => {
                            connection.release();
                            res.status(500).send('Internal Server Error');
                        });
                        return;
                    }

                    // Update stock_total in product table
                    const updateStockPromises = addedItems.map((item) => {
                        return new Promise((resolve, reject) => {
                            const updateStockQuery = `UPDATE product SET stock_total = stock_total - ? WHERE productID = ?`;
                            connection.query(updateStockQuery, [item.quantity, item.productID], (err, result) => {
                                if (err) {
                                    reject(err);
                                } else {
                                    resolve(result);
                                }
                            });
                        });
                    });

                    // Update availability in vehicle table
                    const updateVehicleAvailabilityQuery = 'UPDATE vehicle SET availability = "no" WHERE vehicleID = ?';
                    connection.query(updateVehicleAvailabilityQuery, [vehicleID], (err, updateVehicleResult) => {
                        if (err) {
                            console.error('Error updating vehicle availability:', err);
                            connection.rollback(() => {
                                connection.release();
                                res.status(500).send('Internal Server Error');
                            });
                            return;
                        }

                        // Update availability in salesrep table
                        const updateRepAvailabilityQuery = 'UPDATE salesrep SET availability = "no" WHERE repID = ?';
                        connection.query(updateRepAvailabilityQuery, [repID], (err, updateRepResult) => {
                            if (err) {
                                console.error('Error updating salesrep availability:', err);
                                connection.rollback(() => {
                                    connection.release();
                                    res.status(500).send('Internal Server Error');
                                });
                                return;
                            }

                            Promise.all(updateStockPromises)
                                .then(() => {
                                    connection.commit((err) => {
                                        if (err) {
                                            console.error('Error committing database transaction:', err);
                                            connection.rollback(() => {
                                                connection.release();
                                                res.status(500).send('Internal Server Error');
                                            });
                                            return;
                                        }
                                        res.json({ message: 'Item and products added successfully' }); // Send response indicating successful addition
                                        connection.release();
                                    });
                                })
                                .catch((err) => {
                                    console.error('Error updating product stock:', err);
                                    connection.rollback(() => {
                                        connection.release();
                                        res.status(500).send('Internal Server Error');
                                    });
                                });
                        });
                    });
                });
            });
        });
    });
};


const addLoadingPreOrders = (req, res) => {
    const { total_value, repID, addedItems, vehicleID, userID, loading_status, areaID } = req.body;
    const date = new Date().toISOString().slice(0, 19).replace("T", " ");
    
    // Start a transaction
    DBconnect.getConnection((err, connection) => {
        if (err) {
            console.error('Error getting database connection:', err);
            res.status(500).send('Internal Server Error');
            return;
        }

        connection.beginTransaction((err) => {
            if (err) {
                console.error('Error starting database transaction:', err);
                connection.release();
                res.status(500).send('Internal Server Error');
                return;
            }

            // Insert into loading table
            const insertLoadingQuery = 'INSERT INTO loading (total_value, repID, vehicleID, date, userID, loading_status, areaID) VALUES (?, ?, ?, ?, ?, ?, ?)';
            connection.query(insertLoadingQuery, [total_value, repID, vehicleID, date, userID, loading_status, areaID], (err, loadingResult) => {
                if (err) {
                    console.error('Error inserting item into loading table:', err);
                    connection.rollback(() => {
                        connection.release();
                        res.status(500).send('Internal Server Error');
                    });
                    return;
                }

                const loadingID = loadingResult.insertId;

                // Prepare values for bulk insertion into loading_products table
                const productSaleValues = addedItems.map((item) => [
                    loadingID,
                    item.productID,
                    item.quantity,
                ]);

                // Insert into loading_products table
                const insertLoadingProductsQuery = 'INSERT INTO loading_products (loadingID, productID, quantity) VALUES ?';
                connection.query(insertLoadingProductsQuery, [productSaleValues], (err, productsResult) => {
                    if (err) {
                        console.error('Error inserting items into loading_products table:', err);
                        connection.rollback(() => {
                            connection.release();
                            res.status(500).send('Internal Server Error');
                        });
                        return;
                    }

                    // Update stock_total in product table
                    const updateStockPromises = addedItems.map((item) => {
                        return new Promise((resolve, reject) => {
                            const updateStockQuery = `UPDATE product SET stock_total = stock_total - ? WHERE productID = ?`;
                            connection.query(updateStockQuery, [item.quantity, item.productID], (err, result) => {
                                if (err) {
                                    reject(err);
                                } else {
                                    resolve(result);
                                }
                            });
                        });
                    });

                    // Get the preOrder IDs from addedItems to update their status
                    const preOrderIDs = [...new Set(addedItems.map(item => item.preorderID))];

                    // Update pre_order_status in pre_order table
                    const updatePreOrderStatusPromises = preOrderIDs.map((preorderID) => {
                        return new Promise((resolve, reject) => {
                            const updatePreOrderStatusQuery = `UPDATE pre_order SET pre_order_status = 'processing' WHERE preorderID = ?`;
                            connection.query(updatePreOrderStatusQuery, [preorderID], (err, result) => {
                                if (err) {
                                    reject(err);
                                } else {
                                    resolve(result);
                                }
                            });
                        });
                    });

                    // Update availability in vehicle table
                    const updateVehicleAvailabilityQuery = 'UPDATE vehicle SET availability = "no" WHERE vehicleID = ?';
                    connection.query(updateVehicleAvailabilityQuery, [vehicleID], (err, updateVehicleResult) => {
                        if (err) {
                            console.error('Error updating vehicle availability:', err);
                            connection.rollback(() => {
                                connection.release();
                                res.status(500).send('Internal Server Error');
                            });
                            return;
                        }

                        // Update availability in salesrep table
                        const updateRepAvailabilityQuery = 'UPDATE salesrep SET availability = "no" WHERE repID = ?';
                        connection.query(updateRepAvailabilityQuery, [repID], (err, updateRepResult) => {
                            if (err) {
                                console.error('Error updating salesrep availability:', err);
                                connection.rollback(() => {
                                    connection.release();
                                    res.status(500).send('Internal Server Error');
                                });
                                return;
                            }

                            Promise.all([...updateStockPromises, ...updatePreOrderStatusPromises])
                                .then(() => {
                                    connection.commit((err) => {
                                        if (err) {
                                            console.error('Error committing database transaction:', err);
                                            connection.rollback(() => {
                                                connection.release();
                                                res.status(500).send('Internal Server Error');
                                            });
                                            return;
                                        }
                                        res.json({ message: 'Item and products added successfully' }); // Send response indicating successful addition
                                        connection.release();
                                    });
                                })
                                .catch((err) => {
                                    console.error('Error updating product stock or pre-order status:', err);
                                    connection.rollback(() => {
                                        connection.release();
                                        res.status(500).send('Internal Server Error');
                                    });
                                });
                        });
                    });
                });
            });
        });
    });
};

// Backend API to check if there is any pending loading for the selected salesRep
const checkPendingLoading = (req, res) => {
    const repID = req.body.repID;
    console.log(repID);
  
    const checkPendingLoadingQuery = "SELECT * FROM loading WHERE repID = ? AND loading_status = 'pending'";
  
    DBconnect.query(checkPendingLoadingQuery, [repID], (error, results) => {
      if (error) {
        console.error("Error checking pending loading:", error);
        res.status(500).json({ error: "Error checking pending loading" });
      } else {
        if (results.length > 0) {
          // If there is a pending loading for the selected salesRep
          res.json({ hasPendingLoading: true });
        } else {
          // If there is no pending loading for the selected salesRep
          res.json({ hasPendingLoading: false });
        }
      }
    });
  };


  const updateLoadingStatus = (req, res) => {
    const loadingID = req.body.loadingID; // Assuming loadingID is provided in the request body
  
    const updateLoadingStatusQuery = "UPDATE loading SET loading_status = 'completed' WHERE loadingID = ?";
    const updateVehicleAvailabilityQuery = "UPDATE vehicle v JOIN loading l ON v.vehicleID = l.vehicleID SET v.availability = 'yes' WHERE l.loadingID = ?";
    const updateSalesRepAvailabilityQuery = "UPDATE salesrep SET availability = 'yes' WHERE repID = (SELECT repID FROM loading WHERE loadingID = ?)";
  
    // Execute the first update query to update loading_status
    DBconnect.query(updateLoadingStatusQuery, [loadingID], (error, results) => {
      if (error) {
        console.error("Error updating loading status:", error);
        return res.status(500).json({ error: "Error updating loading status" });
      }
  
      // If loading_status update is successful, execute the second update query to update vehicle availability
      DBconnect.query(updateVehicleAvailabilityQuery, [loadingID], (error, results) => {
        if (error) {
          console.error("Error updating vehicle availability:", error);
          return res.status(500).json({ error: "Error updating vehicle availability" });
        }
  
        // If vehicle availability update is successful, execute the third update query to update salesrep availability
        DBconnect.query(updateSalesRepAvailabilityQuery, [loadingID], (error, results) => {
          if (error) {
            console.error("Error updating salesrep availability:", error);
            return res.status(500).json({ error: "Error updating salesrep availability" });
          }
  
          // Retrieve all loading products for the given loadingID
          const getLoadingProductsQuery = 'SELECT productID, quantity FROM loading_products WHERE loadingID = ?';
  
          DBconnect.query(getLoadingProductsQuery, [loadingID], (err, loadingProducts) => {
            if (err) {
              console.error("Error retrieving loading products:", err);
              return res.status(500).send(err);
            }
  
            // For each loading product, update the stock_total in the products table
            let updatePromises = loadingProducts.map((item) => {
              const updateStockQuery = 'UPDATE product SET stock_total = stock_total + ? WHERE productID = ?';
  
              return new Promise((resolve, reject) => {
                DBconnect.query(updateStockQuery, [item.quantity, item.productID], (err, result) => {
                  if (err) {
                    reject(err);
                  } else {
                    resolve(result);
                  }
                });
              });
            });
  
            // Once all updates are complete, send a success response
            Promise.all(updatePromises)
              .then(() => {
                res.json({ message: "Loading status, vehicle availability, salesrep availability, and stock totals updated successfully" });
              })
              .catch((err) => {
                console.error("Error updating stock totals:", err);
                res.status(500).json({ error: "Error updating stock totals" });
              });
          });
        });
      });
    });
  };
  

  
  const getLoadingById = (req, res) => {
    const loadingID = req.params.loadingID;
    console.log(loadingID);

    const getLoadingQuery = `
    SELECT 
    l.total_value, l.repID, l.vehicleID, l.date, l.userID, l.loading_status,l.loadingID,
    lp.productID, lp.quantity,
    p.product_name, p.selling_price, p.image_path,
    u.firstname as rep_firstname,
    v.vehicle_number
FROM loading l
JOIN loading_products lp ON l.loadingID = lp.loadingID
JOIN product p ON lp.productID = p.productID
JOIN salesrep s ON l.repID = s.repID
JOIN user u ON s.userID = u.userID
JOIN vehicle v ON l.vehicleID = v.vehicleID
WHERE l.loadingID = ?;

    `;

    DBconnect.query(getLoadingQuery, [loadingID], (error, results) => {
        if (error) {
            console.error("Error fetching loading data:", error);
            res.status(500).json({ error: "Error fetching loading data" });
        } else {
            if (results.length > 0) {
                const loadingData = {
                    loadingID: results[0].loadingID,
                    total_value: results[0].total_value,
                    repID: results[0].repID,
                    vehicleID: results[0].vehicleID,
                    date: results[0].date,
                    userID: results[0].userID,
                    loading_status: results[0].loading_status,
                    rep_firstname: results[0].rep_firstname,
                    vehicle_number: results[0].vehicle_number,
                    addedItems: results.map((row) => ({
                        productID: row.productID,
                        product_name: row.product_name,
                        quantity: row.quantity,
                        selling_price: row.selling_price,
                        image_path: row.image_path,
                    })),
                };
                res.json({ loadingData });
            } else {
                res.status(404).json({ error: "Loading data not found" });
            }
        }
    });
};

const editLoading = (req, res) => {
    const { loadingID, total_value, repID, addedItems, vehicleID, userID, loading_status } = req.body;
    const date = new Date().toISOString().slice(0, 19).replace("T", " ");

    console.log(req.body);

    // Start a transaction
    DBconnect.getConnection((err, connection) => {
        if (err) {
            console.error('Error getting database connection:', err);
            res.status(500).send('Internal Server Error');
            return;
        }

        connection.beginTransaction((err) => {
            if (err) {
                console.error('Error starting database transaction:', err);
                connection.release();
                res.status(500).send('Internal Server Error');
                return;
            }

            // Retrieve existing products and quantities associated with the loadingID
            const selectExistingProductsQuery = 'SELECT productID, quantity FROM loading_products WHERE loadingID = ?';
            connection.query(selectExistingProductsQuery, [loadingID], (err, existingProductsResult) => {
                if (err) {
                    console.error('Error retrieving existing products:', err);
                    connection.rollback(() => {
                        connection.release();
                        res.status(500).send('Internal Server Error');
                    });
                    return;
                }

                // Delete existing products associated with the loadingID
                const deleteProductsQuery = 'DELETE FROM loading_products WHERE loadingID = ?';
                connection.query(deleteProductsQuery, [loadingID], (err, deleteResult) => {
                    if (err) {
                        console.error('Error deleting existing products:', err);
                        connection.rollback(() => {
                            connection.release();
                            res.status(500).send('Internal Server Error');
                        });
                        return;
                    }

                    // Add removed quantities back to the stock_total of corresponding products
                    const addStockPromises = existingProductsResult.map((existingProduct) => {
                        return new Promise((resolve, reject) => {
                            const updateStockQuery = 'UPDATE product SET stock_total = stock_total + ? WHERE productID = ?';
                            connection.query(updateStockQuery, [existingProduct.quantity, existingProduct.productID], (err, result) => {
                                if (err) {
                                    reject(err);
                                } else {
                                    resolve(result);
                                }
                            });
                        });
                    });

                    // Retrieve new products added
                    const productSaleValues = addedItems.map((item) => [
                        loadingID,
                        item.productID,
                        item.quantity,
                    ]);

                    // Deduct newly added product quantities from stock_total
                    const deductStockPromises = addedItems.map((item) => {
                        return new Promise((resolve, reject) => {
                            const updateStockQuery = 'UPDATE product SET stock_total = stock_total - ? WHERE productID = ?';
                            connection.query(updateStockQuery, [item.quantity, item.productID], (err, result) => {
                                if (err) {
                                    reject(err);
                                } else {
                                    resolve(result);
                                }
                            });
                        });
                    });

                    // Combine the promises for both deducting and adding stock
                    const allStockPromises = addStockPromises.concat(deductStockPromises);

                    Promise.all(allStockPromises)
                        .then(() => {
                            // Insert new products into loading_products table
                            const insertLoadingProductsQuery = 'INSERT INTO loading_products (loadingID, productID, quantity) VALUES ?';
                            connection.query(insertLoadingProductsQuery, [productSaleValues], (err, productsResult) => {
                                if (err) {
                                    console.error('Error inserting new products:', err);
                                    connection.rollback(() => {
                                        connection.release();
                                        res.status(500).send('Internal Server Error');
                                    });
                                    return;
                                }

                                // Update loading details
                                const updateLoadingQuery = 'UPDATE loading SET total_value = ?, repID = ?, vehicleID = ?, date = ?, userID = ?, loading_status = ? WHERE loadingID = ?';
                                connection.query(updateLoadingQuery, [total_value, repID, vehicleID, date, userID, loading_status, loadingID], (err, loadingResult) => {
                                    if (err) {
                                        console.error('Error updating loading details:', err);
                                        connection.rollback(() => {
                                            connection.release();
                                            res.status(500).send('Internal Server Error');
                                        });
                                        return;
                                    }

                                    // Update availability of the vehicle
                                    const updateVehicleAvailabilityQuery = 'UPDATE vehicle SET availability = "no" WHERE vehicleID = ?';
                                    connection.query(updateVehicleAvailabilityQuery, [vehicleID], (err, updateVehicleResult) => {
                                        if (err) {
                                            console.error('Error updating vehicle availability:', err);
                                            connection.rollback(() => {
                                                connection.release();
                                                res.status(500).send('Internal Server Error');
                                            });
                                            return;
                                        }

                                        // Commit transaction
                                        connection.commit((err) => {
                                            if (err) {
                                                console.error('Error committing database transaction:', err);
                                                connection.rollback(() => {
                                                    connection.release();
                                                    res.status(500).send('Internal Server Error');
                                                });
                                                return;
                                            }
                                            res.json({ message: 'Item and products added successfully' }); // Send response indicating successful addition
                                            connection.release();
                                        });
                                    });
                                });
                            });
                        })
                        .catch((err) => {
                            console.error('Error updating stock:', err);
                            connection.rollback(() => {
                                connection.release();
                                res.status(500).send('Internal Server Error');
                            });
                        });
                });
            });
        });
    });
};

const getReturnLoad = (req, res) => {
    const { loadingID } = req.params;
    const query = 'SELECT productID, quantity FROM loading_products WHERE loadingID = ?';
    
    DBconnect.query(query, [loadingID], (err, results) => {
      if (err) {
        return res.status(500).send(err);
      }
      res.json(results);
    });
  };

  

module.exports = {
    addLoading,
    checkPendingLoading,
    updateLoadingStatus,
    getLoadingById,
    editLoading,
    addLoadingPreOrders,
    getReturnLoad,
};
